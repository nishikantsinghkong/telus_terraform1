#############################
KONG-API Installation steps:-
#############################

Pre-Tasks:-

1) Execute "gcloud auth login" and "gcloud auth application-default login" from commandline and enter your telus GSuite account address/password and click on Allow
2) set up the proxy " export https_proxy=http://198.161.14.26:1328"
3) Execte "gcloud container clusters get-credentials td-gke-kong-yul-001-np --region northamerica-northeast1 --project td-gke-kong-yul-001-np-5054"
4) Execute kubectl config current-context to make sure you are exeucting the scripts in right cluster
6) cd %local_path%/digital-kong/terraform/kong-np/kong-clusters/private-yul-np-001/kong-ee/terraform

7)
Validation before secrets creation
$ kubectl get secret -n kong-ee
NAME                  TYPE                                  DATA   AGE
default-token-k7cfm   kubernetes.io/service-account-token   3      43h

8) 
kubectl apply -f td-gcr-imagepull-key-secret.yaml -n kong-ee
kubectl apply -f admin-gui-session-conf.yaml -n kong-ee
kubectl apply -f kong-license-secret.yaml -n kong-ee
kubectl apply -f kong-enterprise-superadmin-password.yaml -n kong-ee
kubectl apply -f pg-password-secret.yaml -n kong-ee

9) Validation After secrets creation
$ kubectl get secrets -n kong-ee
NAME                                                TYPE                                  DATA   AGE
default-token-k7cfm                                 kubernetes.io/service-account-token   3      5d22h
kong-admin-gui-session-conf                         Opaque                                1      4d1h
kong-ee-ingress-protected-kong-token-pv82d          kubernetes.io/service-account-token   3      61m
kong-enterprise-superadmin-password                 Opaque                                1      4d1h
kong-license                                        Opaque                                1      4d1h
pg-password                                         Opaque                                1      4m11s
postgres-tls-secret                                 Opaque                                2      3d16h
td-gcr-imagepull-key                                kubernetes.io/dockerconfigjson        1      4d2h


Generate the CloudSQL client certs

1) Login into google cloud console
2) Select the right project where your env CloudSQLs are up and running example: td-gke-kong-apigw-yul-np
3) Search for SQL and click on it
4) select cloud SQL db instance example: td-gke-kong-apigw-yul-np-001-5d4585 and click on it
5) Go to Connections
6) Look for CREATE CLIENT CERTIFICATE and click on it
7) Please download key,crt, server-ca .pem files to your local laptop 
  example: cd  /c/pitchireddythota/EM_Middleware/KongAPI/TD_GCP/DB_client_certs/np-api
8) Create a secret by using following commands 
  kubectl create secret generic postgres-tls-secret --from-file=tls.crt="client-cert.pem" --from-file=tls.key="client-key.pem" --dry-run=client -o yaml > output
9) Apply the generated output on kubernetes cluster
  example:
    $ kubectl apply -f output -n kong-ee
      secret/postgres-tls-secret created
10) validate the secret "postgres-tls-secret" on the cluster is created or not
    Example
$ kubectl get secret -n kong-ee-web
NAME                                  TYPE                                  DATA   AGE
default-token-mch4g                   kubernetes.io/service-account-token   3      6d23h
kong-admin-gui-session-conf           Opaque                                1      4m37s
kong-enterprise-superadmin-password   Opaque                                1      4m19s
kong-license                          Opaque                                1      4m30s
pg-password                           Opaque                                1      4m12s
postgres-tls-secret                   Opaque                                2      7s
td-gcr-imagepull-key                  kubernetes.io/dockerconfigjson        1      4m51s

Security policy creation:-
Please create it if it does not exist
1.	In the Google Cloud Console, go to the Network Security page.
2.	Go to Network Security
3.	On the Policies page, click Create policy.
4.	In the Name field, enter td-gke-kong-yul-001-np-waf-enabled-telus-ip-filter-allow
5.	In the Description field, enter Policy for external users.
6.	For Default rule action, select Allow.
7.	Click on Create Policy


Create pre-shared-cert:
1) with the name of "td-cloudapps-telus-com-certificate" to support certificate_name from Kong Ingress


Create Backend config:-
It is not needed as it is handling via  post-install-ingress-config of helm_release from kong-ingress-common

Reserve External static IPs only for Admins manually

1.	Go to the Reserve a static address page
2.	Go to Reserve a static address
3.	Choose a name for the new address
4.	Specify whether it is an IPv4 
5.	Specify whether this IP address is regional
6.	If this is a regional IP address, select the region to create the address in.
7.	Click Reserve to reserve the IP


Reserve Internal static IPs only for internal LBs manually

1.	Go to the VPC networks page.
2.	Go to VPC networks
3.	Click the VPC network that you want to reserve the new static IP in.
4.	Click Static internal IP addresses and then click Reserve static address.
5.	Enter a Name for this IP address.
6.	Select a Subnet.
7.	If you want to specify which IP address to reserve, under Static IP address, select Let me choose, then fill in a Custom IP address. Otherwise the system automatically assigns an IP address in the subnet for you.
8.	If you want to share this IP in different frontends, under Purpose, choose Non-Shared.
9.	Click Reserve to finish the process.

#######################
Kong Installation:-
#######################

1) Execute "gcloud auth login" and "gcloud auth application-default login" from commandline and enter your telus GSuite account address/password and click on Allow
2) set up the proxy " export https_proxy=http://198.161.14.26:1328"
3) Execte "gcloud container clusters get-credentials td-gke-kong-yul-001-np --region northamerica-northeast1 --project td-gke-kong-yul-001-np-5054"
4) Execute kubectl config current-context to make sure you are exeucting the scripts in right cluster
5) cd %local_path%/digital-kong/terraform/kong-np/kong-clusters/private-yul-np-001/kong-ee/terraform
6) Please ignore this step if the CRDs are already installed. if CRDs are not installed, please install CRDs before proceeding with the Kong installation becuase it is a manual work from 1.11.0 chart 
  https://github.com/Kong/charts/blob/main/charts/kong/UPGRADE.md#1110
  Apply CRDs via kubectl apply -f https://raw.githubusercontent.com/Kong/charts/main/charts/kong/crds/custom-resource-definitions.yaml
  Validate the CRDs are created or not
  $ kubectl get crds|grep kong
  kongclusterplugins.configuration.konghq.com      2021-10-18T21:12:08Z
  kongconsumers.configuration.konghq.com           2021-10-18T21:12:08Z
  kongingresses.configuration.konghq.com           2021-10-18T21:12:08Z
  kongplugins.configuration.konghq.com             2021-10-18T21:12:09Z
  tcpingresses.configuration.konghq.com            2021-10-18T21:12:09Z
  udpingresses.configuration.konghq.com            2021-10-18T21:12:10Z
7) helm repo update
  Execute below steps if the Kong and Redis charts are added to help repo list or not
  $ helm repo list
  NAME    URL
  kong    https://charts.konghq.com
  bitnami https://charts.bitnami.com/bitnami
8) rm -rf .terraform
9) terraform init
10) terraform plan
11) terraform apply

Testing from portforward
export https_proxy=http://198.161.14.26:1328
gcloud container clusters get-credentials td-gke-kong-yul-001-np --region northamerica-northeast1 --project td-gke-kong-yul-001-np-5054
kubectl get pods -n kong-ee
kubectl port-forward kong-ee-web-ingress-protected-kong-578bb9ddd6-2dcvd 443 8443 8444 8445 8446 -n kong-ee

Submit DNS request via following steps:-
1. Fork the code from https://github.com/telus/cio-cloudapps-dns.git
2. Clone forked repo in your local
3. Go to *cio-cloudapps-dns\terraform\kong-ee.tf in your local folder where you forked the repo
4. Make following changes



