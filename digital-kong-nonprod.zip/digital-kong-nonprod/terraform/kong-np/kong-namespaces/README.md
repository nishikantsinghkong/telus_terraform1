These are steps when we execute the terrafom local laptop

1) Execute "gcloud auth login" from commandline and enter your telus GSuite account address/password and click on Allow
2) set up the proxy " export https_proxy=http://198.161.14.26:1328"
3) Execte "gcloud container clusters get-credentials td-gke-kong-yul-001-np --region northamerica-northeast1 --project td-gke-kong-yul-001-np-5054"
4) Execute kubectl config current-context to make sure you are exeucting the scripts in right cluster
5) cd %local_path%/digital-kong/terraform/kong-np/kong-namespaces/
6) terraform init
7) terraform plan
8) terraform apply


