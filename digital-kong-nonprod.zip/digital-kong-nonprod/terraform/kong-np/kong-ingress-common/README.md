# tf-module-gcp-kong-ingress
Common module to install Kong ingress / gw on GKE cluster

## Vanity Domain Support

If teams require a custom domain name that is not under *.cloudapps.telus.com, then it is that teams responsibility to submit the DNS request for a CNAME entry in telus.com
pointing at our general ingress DNS.

For example to have a domain foobar.telus.com on the public-yul-np-002 cluster, the user would have a CNAME created for foobar.telus.com pointing at 
public-public-yul-np-002.cloudapps.telus.com.

The cluster administrator will then add that domain to the nginx module configuration.  This is a list and multiple domains can be supported, up to 100 which
is the current google limit.

module "kong-ingress-protected" {
  ...
  certificate_domains   = ["foobar.telus.com",]
  ...
}

When applied, this will create a managedcertificate resource in the nginx namespace to create a google managed certificate.
```
apiVersion: networking.gke.io/v1
kind: ManagedCertificate
metadata:
  annotations:
    meta.helm.sh/release-name: foobar.telus.com-managedcertificate
    meta.helm.sh/release-namespace: nginx-ingress
  creationTimestamp: "2020-11-26T16:28:48Z"
  generation: 4
  labels:
    app.kubernetes.io/managed-by: Helm
  name: foobar-telus-com
  namespace: nginx-ingress
  resourceVersion: "97315910"
  selfLink: /apis/networking.gke.io/v1/namespaces/nginx-ingress/managedcertificates/foobar-telus-com
  uid: 67ce89b8-53f2-4c38-9a1f-f52d217909ba
spec:
  domains:
  - foobar.telus.com
status:
  certificateName: mcrt-9b22a32f-99db-4d66-9c51-e5bf5460aa80
  certificateStatus: Active
  domainStatus:
  - domain: foobar.telus.com
    status: Active
  expireTime: "2021-02-24T08:07:43.000-08:00"
```

Once the cert is created it will go into an Active state.  For google to create the cert, the DNS must exist and resolve properly.

The managedcertificate name also gets appended to the managed-certificates annotation on the ingress.

```
    networking.gke.io/managed-certificates: foobar-telus-com
```
