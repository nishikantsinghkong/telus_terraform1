CHANGE LOG
v0.1.2 - iLB issues fixed.

v0.1.3 - removed lifeccle management for ingress

v0.1.4 - parameterized health check url

v0.1.5.alpha - added support for custom domains and their managed certs

v0.1.6 - changed api version for backendconfig to "cloud.google.com/v1"
    v0.1.6.1 - updated chart version

v0.1.7 - added support to pass list of extra pre-shared-cert in addition to base kong ingress cert