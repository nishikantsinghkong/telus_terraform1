# google_system_account

This module provides the names of the Google-created service accounts for system services.

## inputs

* `project_id`: A Google project identifier

## outputs

The outputs that end with `email` are the service account e-mails. The corresponding output
that ends in `member` is the same value but with the `serviceAccount:` prefix added for
ease of use with IAM binding `member` attributes.

* `app_email`: AppEngine service account e-mail
* `app_member`: AppEngine member specification for IAM binding
* `build_email`: Cloud Build service account e-mail
* `build_member`: Cloud Build member specification for IAM binding
* `gke_email`: GKE service account e-mail
* `gke_member`: GKE member specification for IAM binding
* `pubsub_email`: Pub/Sub service account e-mail
* `pubsub_member`: Pub/Sub member specification for IAM binding
* `run_email`: Cloud Run service account e-mail
* `run_member`: Cloud Run member specification for IAM binding
