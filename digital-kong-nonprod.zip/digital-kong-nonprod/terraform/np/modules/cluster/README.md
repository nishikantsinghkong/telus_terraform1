# platform_containers
Deploy a zonal Kubernetes cluster to Google Cloud Platform.

## Environment Variables
Variables without default are required.

**`project_id`**
- The project ID where the cluster will run.

**`project_number`**
- The project number where the service runs.

**`region`**
- The default region for this cluster.

**`bucket_containers`**
- The storage bucket containing your artifacts which will be deployed to your cluster.
- Gives the default Kubernetes service account `objectViewer` on this bucket. 

**`name`**
- The cluster, network, and subnetwork name.

**`cluster_version_min`**
- The minimum cluster version.
- Can be partial string as version searching/matching is done.
- **Default:** the latest stable channel version, if not specified. [See versions](https://cloud.google.com/kubernetes-engine/docs/release-notes-stable).

**`enable_shielded_nodes`**
- Whether to enable shielded nodes.
- **Default:** `true`

**`issue_client_certificates`**
- Whether to issue client certificates for cluster access.
- **Default:** `false`

**`nat_ip_count`**
- The number of static, global, external IP addresses to attach to Cloud NAT.
- **Default:** `1`

**`node_count_initial`**
- The initial number of nodes to run in each zone. Changing this will force a cluster re-build in full.

**`node_count_min`**
- The minimum autoscaling node count.

**`node_count_max`**
- The maximum autoscaling node count.

**`node_preemptible`**
- Whether to deploy pre-emptible (spot instances) in your node pool.
- **Default:** `false`

**`node_type`**
- The node type used for the Kubernetes compute nodes

**`node_disk_type`**
- Type of the disks attached to each compute node

**`node_disk_size`**
Size of the disks attached to each compute node, in GB

# Contributors
* [Aaron Fagan](https://github.com/aaronfagan)
* [Phil Dufualt](https://github.com/phildufault)